package au.net.api.loyalty

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import static java.util.Calendar.*;

/* ************************************************************************
    Program     : SetTimePeriod.groovy
    Create Date : July-13-2020
    Author      : Stephen Xue
    Function    :
        1. Get Start time and End Time from system time;
        2. Write to properties.

    input: empty
    output:
 *************************************************************************/
def Message processData(Message message, def testFlag = null) {
    def localTimeZone = TimeZone.getTimeZone('Australia/Melbourne');
    def cal           = Calendar.instance;
    def date          = cal.time;
    def dateFormat    = 'yyyy-MM-dd';
    //Header

    def yesterday = date.plus(-1).format(dateFormat, localTimeZone);
    def startTime = yesterday + 'T00:00:00';
    def endTime   = yesterday + 'T23:59:59';
    message.setProperty('startTime', startTime);
    message.setProperty('endTime', endTime);
    return message;
}